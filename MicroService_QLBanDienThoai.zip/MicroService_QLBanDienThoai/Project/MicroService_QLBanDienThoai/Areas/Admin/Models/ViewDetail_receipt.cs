﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService_QLBanDienThoai.Areas.Admin.Models
{
    public class ViewDetail_receipt
    {
        public int Product_ID { get; set; }
        public int Quantity { get; set; }
    }
}
