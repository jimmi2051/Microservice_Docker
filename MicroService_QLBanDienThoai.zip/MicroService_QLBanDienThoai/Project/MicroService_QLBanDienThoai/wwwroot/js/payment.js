﻿function clickShowFooter(a) {
    $('#' + a).slideToggle();
}